from enum import Enum


class Exchange(Enum):
    COINBASE = "coinbase"
    COINBASEPRO = "coinbasepro"
    BINANCE = "binance"
    KUCOIN = "kucoin"
    DUMMY = "dummy"
